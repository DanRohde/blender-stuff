import bpy
from .edit_panel import draw_list_selection_actions, draw_list_order_actions, WFC3DULGenericFilter
from .helper import count_selected_items, seed_in_seeds_list

class VIEW3D_UL_SeedsList(bpy.types.UIList, WFC3DULGenericFilter):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, index):
        row = layout.row(align=True)
        col = row.column(align=True)
        row = col.row(align=True)
        row.prop(item, "collapsed", emboss=False, icon="RIGHTARROW" if item.collapsed else "DOWNARROW_HLT")
        row.prop(item, "selected", text=f"{item.seed}", icon="BOOKMARKS",)
        c = row.column(align=True)
        c.alignment = "EXPAND"
        c.prop(item, "note", text="", placeholder="Optional note")
        row.operator("object.wfc_set_seed_direct", icon="PLAY").item_idx = index

        if item.collapsed: return
        row = col.row()
        row.label(text=f"Source: {item.collection_obj.name}")
        row.label(text=f"Entropy: {item.entropy_type}")
        row = col.row(align=True)
        row.column(align=True).label(text=f"Grid Size: ")
        row.column(align=True).label(text=f"{item.grid_size[0]:5d}")
        row.column(align=True).label(text=f"{item.grid_size[1]:5d}")
        row.column(align=True).label(text=f"{item.grid_size[2]:5d}")
        if item.auto_detect_spacing:
            col.row().label(text="Automatic spacing detection", icon="CHECKBOX_HLT")
        else:
            row = col.row(align=True)
            row.column(align=True).label(text=f"Space: ")
            row.column(align=True).label(text=f"{item.spacing[0]:5.2f} m")
            row.column(align=True).label(text=f"{item.spacing[1]:5.2f} m")
            row.column(align=True).label(text=f"{item.spacing[2]:5.2f} m")
        row = col.row(align=True)
        row.column(align=True).label(text=f"Odd Offest: ")
        row.column(align=True).label(text=f"{item.odd_offset[0]:5.2f} m")
        row.column(align=True).label(text=f"{item.odd_offset[1]:5.2f} m")
        row.column(align=True).label(text=f"{item.odd_offset[2]:5.2f} m")
        row = col.row(align=True)
        row.column(align=True).label(text=f"Location: ")
        row.column(align=True).label(text=f"{item.location[0]:5.2f} m")
        row.column(align=True).label(text=f"{item.location[1]:5.2f} m")
        row.column(align=True).label(text=f"{item.location[2]:5.2f} m")
        row = col.row()
        row.label(text="Use Constraints", icon="CHECKBOX_HLT" if item.use_constraints else "CHECKBOX_DEHLT")
        row.label(text="Random Start Cell", icon="CHECKBOX_HLT" if item.random_start_cell else "CHECKBOX_DEHLT")
        col.row().label(text=f"Timestamp: {item.timestamp}")

class OBJECT_PT_SeedsPanel(bpy.types.Panel):
    """User interface for WFC 3D Seeds"""
    bl_label = ""
    bl_idname = "VIEW3D_PT_wfc_seeds"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'WFC 3D Gen'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.wfc_props
        sel_count = count_selected_items(props.seeds_input_list)
        row = layout.row()
        col = row.column()
        col.template_list("VIEW3D_UL_SeedsList", "", props, "seeds_input_list", props, "seeds_input_list_idx", rows=1, maxrows=2, sort_lock=True)
        r = col.row()
        draw_list_order_actions(props, r, "seeds_input_list", call_auto_save=False)
        r.label(text=f"Random Seeds: {len(props.seeds_input_list)}")
        col = row.column()
        col.operator("object.wfc_add_seed_list_item", icon="BOOKMARKS", text="", depress=seed_in_seeds_list(props)[0])
        c = col.column()
        c.operator("object.wfc_remove_seed_list_items", icon="REMOVE", text="")
        c.enabled = sel_count > 0
        col.separator()
        draw_list_selection_actions(props, col, "seeds_input_list")

    def draw_header(self, context):
        self.layout.row().label(text=f"WFC 3D Random Seeds ({len(context.scene.wfc_props.seeds_input_list)})", icon="BOOKMARKS")

panels = [ VIEW3D_UL_SeedsList, OBJECT_PT_SeedsPanel ]
