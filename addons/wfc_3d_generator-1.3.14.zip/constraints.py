import bpy
import numpy as np
from itertools import product
from mathutils import Vector, Matrix
import random
from collections import deque

from .constants import *
from .helper import get_default_empty_object, get_default_empty_name, get_better_noise, remap, get_active_constraints, get_directions_by_name
from .geometry import compare_edges, compare_faces

class WFC3DConstraints:
    def __init__(self):
        self.constraints = {}
        self.objects = {}
        self.auto_weights = {}
        self.sympartner = []
        self.sympartner_obj = []
        self.symtransform = []
        self.symflip = []
        self.grid = None
        self.cache_geometry_compare = {}
        self.collection = None
        self.spacing = None
        self.noise_pos = None
        self.active_constraints = None
    
    def initialize_constraints(self, grid, collection, objects, spacing):
        """Loads constraints from custom properties"""
        self.objects = objects
        default_obj = get_default_empty_object(collection)
        self.collection = collection
        self.grid = grid
        self.sympartner = np.empty(grid.grid_size, dtype=object)
        self.sympartner_obj = np.empty(grid.grid_size, dtype=object)
        self.symtransform = np.empty(grid.grid_size, dtype=object)
        self.symflip = np.empty(grid.grid_size, dtype=object)
        self.spacing = spacing

        self.active_constraints = get_active_constraints()

        for obj in objects:
            obj_name = obj.name
            self.constraints[obj_name] = {}
            self.cache_geometry_compare[obj_name] = {}
            if obj_name in bpy.data.collections:
                obj = get_default_empty_object(bpy.data.collections[obj_name])
                if obj is None: obj = bpy.data.collections[obj_name].objects[0]

            # load probability, frequency, transformation, symmetry, region, neighbor
            for p in GEN_CONSTRAINTS + ADD_NEIGHBOR_CONSTRAINTS:
                cp = "wfc_"+p
                if p in LIST_CONSTRAINTS:
                    self.constraints[obj_name][p] = []
                    if cp in obj: self.constraints[obj_name][p].append(obj[cp]) # backward compatibility
                    if default_obj is not None:
                        idx = 0
                        while f"{cp}_{idx}" in default_obj:
                            self.constraints[obj_name][p].append(default_obj[f"{cp}_{idx}"])
                            idx += 1
                    idx = 0
                    while f"{cp}_{idx}" in obj:
                        self.constraints[obj_name][p].append(obj[f"{cp}_{idx}"])
                        idx += 1
                    if cp in obj and len(self.constraints[obj_name][p])==0: self.constraints[obj_name][p].append(obj[cp]) # backward compatibility
                elif p in SELECTION_CONSTRAINTS:
                    if cp in obj:
                        self.constraints[obj_name][p] = obj[cp].split(",")
                    elif default_obj is not None and cp in default_obj:
                        self.constraints[obj_name][p] = default_obj[cp].split(",")
                    else:
                        self.constraints[obj_name][p] = PROP_DEFAULTS[p]
                elif cp in obj and obj[cp] != "":
                    self.constraints[obj_name][p] = obj[cp]
                elif default_obj and cp in default_obj and default_obj[cp] != "":
                    self.constraints[obj_name][p] = default_obj[cp]
                else:
                    self.constraints[obj_name][p] = PROP_DEFAULTS[p]

            # load grid constraints
            for c in GRID_CONSTRAINTS:
                cp = "wfc_"+c
                if cp in obj and obj[cp] != "":
                    self.constraints[obj_name][c] = obj[cp].split(",")
                elif default_obj and cp in default_obj and default_obj[cp] != "":
                    self.constraints[obj_name][c] = default_obj[cp].split(",")
                else:
                    self.constraints[obj_name][c] = PROP_DEFAULTS[c].split(",")

            for direction in DIRECTIONS:
                if direction.startswith("ANY"): continue
                # init connector exclusion constraints variables:
                if "conn_excl" not in self.constraints[obj_name]: self.constraints[obj_name]["conn_excl"] = {}
                if direction not in self.constraints[obj_name]["conn_excl"]: self.constraints[obj_name]["conn_excl"][direction] = []
                # init multiple connector constraints variables:
                if "mult_conn" not in self.constraints[obj_name]: self.constraints[obj_name]["mult_conn"] = {}
                if direction not in self.constraints[obj_name]["mult_conn"]: self.constraints[obj_name]["mult_conn"][direction] = []

                dirlower = direction.lower()
                # load connector constraints:
                self.constraints[obj_name]["conn_"+dirlower] = self.get_adjacency_property_value(direction, 'conn_', obj, default_obj)
                # load neighbor constraints:
                val  = self.get_adjacency_property_value(direction,'', obj, default_obj)
                self.constraints[obj_name][dirlower] = None if val == '' else val.split(',')

            # connector exclusion constraints:
            self._init_connector_constraints(obj_name, obj, "conn_excl")
            # multiple connector constraints:
            self._init_connector_constraints(obj_name, obj, "mult_conn")

        ## collect distance from object constraints:
        ddd = { }
        for obj in objects:
            for i, distance in enumerate(self.constraints[obj.name]['distance']):
                df = self.constraints[obj.name]['distance_from'][i]
                if df not in [0,2]: continue
                from_object = self.constraints[obj.name]['distance_object'][i] if df == 0 else self.constraints[obj.name]['distance_subcollection'][i]
                if from_object is None or obj.name == from_object.name: continue
                if from_object.name not in ddd: ddd[from_object.name] = { 'distance': [], 'distance_from': [] , 'distance_object': [], 'distance_subcollection': [], 'distance_type' : [] }
                ddd[from_object.name]['distance'].append(distance)
                ddd[from_object.name]['distance_from'].append(0 if obj.name in collection.objects else 2)
                ddd[from_object.name]['distance_object'].append(obj if obj.name in collection.objects else None)
                ddd[from_object.name]['distance_subcollection'].append(obj if obj.name in collection.children else None)
                ddd[from_object.name]['distance_type'].append(self.constraints[obj.name]['distance_type'])
        ## initialize reversed distance constraints:
        for obj_name in ddd:
            for i, distance in enumerate(ddd[obj_name]['distance']):
                self.constraints[obj_name]['distance'].append(distance)
                self.constraints[obj_name]['distance_from'].append(ddd[obj_name]['distance_from'][i])
                self.constraints[obj_name]['distance_object'].append(ddd[obj_name]['distance_object'][i])
                self.constraints[obj_name]['distance_subcollection'].append(ddd[obj_name]['distance_subcollection'][i])
                self.constraints[obj_name]['distance_type'].append(ddd[obj_name]['distance_type'][i])


    def _init_connector_constraints(self, obj_name, obj, prop_prefix):
        """Initialize (multiple) connector (exclusion) constraints"""
        idx = 0
        while f"wfc_{prop_prefix}_name_{idx}" in obj:
            dirpropname = f"{prop_prefix}_direction_{idx}"
            name = obj[f"wfc_{prop_prefix}_name_{idx}"]
            idx += 1
            dirpropidx = obj[f"wfc_{dirpropname}"]
            enumvalues = ENUM_CONSTRAINTS[f'{prop_prefix}_direction']
            if name == "" or not (0 <= dirpropidx < len(enumvalues)): continue
            dirpropvalue = enumvalues[dirpropidx]
            if dirpropvalue.startswith("ANY"):
                if dirpropvalue == "ANY_EDGES": directions = EDGE_DIRECTIONS
                elif dirpropvalue == "ANY_CORNERS": directions = CORNER_DIRECTIONS
                elif dirpropvalue == "ANY_FACES": directions = FACE_DIRECTIONS
                else: directions = DIRECTIONS
                for d in directions:
                    if d.startswith("ANY"): continue
                    self.constraints[obj_name][prop_prefix][d].append(name)
            else:
                self.constraints[obj_name][prop_prefix][dirpropvalue].append(name)

    def get_adjacency_property_value(self, direction, prefix, obj, default_obj):
        cname = prefix + direction.lower()
        prop_name = f"wfc_{cname}"
        any_prop_name = f"wfc_{prefix}any"
        any_face_prop_name = f"wfc_{prefix}any_face"
        any_edge_prop_name = f"wfc_{prefix}any_edge"
        any_corner_prop_name = f"wfc_{prefix}any_corner"

        val = PROP_DEFAULTS[cname]
        if prop_name in obj and obj[prop_name] != "":
            val = obj[prop_name]
        elif any_face_prop_name in obj and obj[any_face_prop_name] != "" and direction in FACE_DIRECTIONS:
            val = obj[any_face_prop_name]
        elif any_edge_prop_name in obj and obj[any_edge_prop_name] != "" and direction in EDGE_DIRECTIONS:
            val = obj[any_edge_prop_name]
        elif any_corner_prop_name in obj and obj[any_corner_prop_name] != "" and direction in CORNER_DIRECTIONS:
            val = obj[any_corner_prop_name]
        elif any_prop_name in obj and obj[any_prop_name] != "":
            val = obj[any_prop_name]
        elif default_obj:
            if prop_name in default_obj and default_obj[prop_name] != "":
                val = default_obj[prop_name]
            elif any_face_prop_name in default_obj and default_obj[any_face_prop_name] != "" and direction in FACE_DIRECTIONS:
                val = default_obj[any_face_prop_name]
            elif any_edge_prop_name in default_obj and default_obj[any_edge_prop_name] != "" and direction in EDGE_DIRECTIONS:
                val = default_obj[any_edge_prop_name]
            elif any_corner_prop_name in default_obj and default_obj[any_corner_prop_name] != "" and direction in CORNER_DIRECTIONS:
                val = default_obj[any_corner_prop_name]
            elif any_prop_name in default_obj and default_obj[any_prop_name] != "":
                val = default_obj[any_prop_name]
        return val

    def sum_weights(self, cell):
        x, y, z = cell
        total = 0
        weights = []
        for element in self.grid.grid[x, y, z]:
            weight = self.get_auto_weight(element)
            if weight == 0: weight = self.constraints[element]['weight']
            weights.append(weight)
            total += weight
        return total, weights

    def get_shannon_entropy(self, cell):
        x, y, z = cell
        total, weights = self.sum_weights(cell)
        if total == 0: return 0.0
        shannon_entropy = 0
        for w in weights:
            if w <= 0: continue
            p = w / total
            shannon_entropy -= p * np.log(p)
        return shannon_entropy

    def get_optimized_entropy(self, cell):
        total, weights = self.sum_weights(cell)
        if total == 0: return 0.0
        sum_w_log_w = sum(w * np.log(w) for w in weights if w > 0)
        return np.log(total) - sum_w_log_w / total

    def get_entropy(self, cell, entropy_type):
        if entropy_type == "optimized": return self.get_optimized_entropy(cell)
        if entropy_type == "shannon": return self.get_shannon_entropy(cell)
        return len(self.grid.grid[cell[0], cell[1], cell[2]])

    def apply_noise_randomize_position_constraint(self, obj_name, pos):
        if not self.constraints[obj_name]['noise_randomize_position']: return pos
        if self.noise_pos is None: self.noise_pos = np.random.rand(1,3)
        return [a*b for a, b in zip(self.noise_pos[0], pos)]

    def are_grid_constraints_satisfied(self, name, pos):

        if "frequency" in self.active_constraints:
            if self.constraints[name]['freq_grid'] == 0: return False
            if self.constraints[name]['freq_grid_pct'] == 0: return False
        if "probability" in self.active_constraints:
            if self.constraints[name]['probability'] == 0 or self.constraints[name]['weight'] == 0: return False
        if "region" in self.active_constraints:
            if not self.grid.is_inside_region(pos, self.constraints[name].get('region_min', None), self.constraints[name].get('region_max', None)): return False
            if not self.grid.is_inside_region_quadrant(pos, self.constraints[name]['region_quadrant']): return False
            if not self.constraints[name]['region_level_ground'] and pos[2] == 0: return False
            if not self.constraints[name]['region_level_first'] and pos[2] == 1: return False
            if not self.constraints[name]['region_level_second'] and pos[2] == 2: return False
            if not self.constraints[name]['region_level_mid'] and 2  < pos[2] < self.grid.grid_size[2]-2: return False
            if not self.constraints[name]['region_level_penultimate'] and pos[2] == self.grid.grid_size[2]-2: return False
            if not self.constraints[name]['region_level_top'] and pos[2] == self.grid.grid_size[2]-1: return False

        if "grid" in self.active_constraints:
            if self.grid.is_corner(pos) and len(self.constraints[name]['corners']) > 0:
                ret = False
                for c in self.constraints[name]['corners']:
                    if c == '' and len(self.constraints[name]['corners']) == 1: ret = True
                    if c != '-' and self.grid.is_on_given_corner(pos, c): ret = True
                if not ret: return ret
            if self.grid.is_edge(pos) and len(self.constraints[name]['edges']) > 0:
                ret = False
                for e in self.constraints[name]['edges']:
                    if e == '' and len(self.constraints[name]['edges']) == 1: ret = True
                    if e != '-' and self.grid.is_on_given_edge(pos, e): ret = True
                if not ret: return ret
            if self.grid.is_inside(pos):
                for inside in self.constraints[name]['inside']:
                    if inside == '-' or inside == 'None' or inside == 'False': return False
            if self.grid.is_face(pos):
                ret = False
                for f in self.constraints[name]['faces']:
                    if f == '' and len(self.constraints[name]['faces']) == 1: ret = True
                    if f != '-' and self.grid.is_on_specific_face(pos, f): ret = True
                if not ret: return ret
        if "regprob" in self.active_constraints:
            for i in range(len(self.constraints[name]['regprob_probability'])):
                pmin = self.grid.fix_position(self.constraints[name]['regprob_min'][i])
                pmax = self.grid.fix_position(self.constraints[name]['regprob_max'][i])
                if self.constraints[name]['regprob_probability'][i] != 0 and self.constraints[name]['regprob_weight'][i] != 0:
                    if self.grid.is_inside_region(pos, pmin, pmax): break
                    continue
                if self.grid.is_inside_region(pos, pmin, pmax): return False
        if "regfreq" in self.active_constraints:
            for i in range(len(self.constraints[name]['regfreq_freq'])):
                pmin = self.grid.fix_position(self.constraints[name]['regfreq_min'][i])
                pmax =  self.grid.fix_position(self.constraints[name]['regfreq_max'][i])
                if ((self.constraints[name]['regfreq_freq'][i] > 0 and (i < len(self.constraints[name]['regfreq_freq_pct']) or self.constraints[name]['regfreq_freq_pct'][i] > 0))
                        and self.grid.is_inside_region(pos, pmin, pmax)): break
                if ((self.constraints[name]['regfreq_freq'][i] == 0 or (i < len(self.constraints[name]['regfreq_freq_pct']) and self.constraints[name]['regfreq_freq_pct'][i] == 0))
                        and self.grid.is_inside_region(pos, pmin, pmax)): return False
        if "noise" in self.active_constraints:
            if self.constraints[name]['noise_prob_function'] > 0:
                n = get_better_noise(self.apply_noise_randomize_position_constraint(name, pos), self.constraints[name],'noise_prob', 0, 1)
                return n >= self.constraints[name]['noise_prob_threshold']
        return True

    def get_auto_weight(self, name):
        if "probability" not in self.active_constraints: return 0
        if not self.constraints[name].get('auto_weight', False): return 0
        if self.auto_weights.get(name, -1) != -1: return self.auto_weights.get(name)

        weight = 0
        for d in DIRECTIONS:
            dl = d.lower()
            if dl not in self.constraints[name] or self.constraints[name][dl] == "" or self.constraints[name][dl] is None:
                weight += len(self.objects)
            else:
                weight += len(self.constraints[name][dl])

        for c in CONNECTOR_CONSTRAINTS:
            if c not in self.constraints[name] or self.constraints[name][c] == "" or self.constraints[name][c] is None:
                weight += len(self.objects)
            else:
                weight += 1
        for c in GRID_CONSTRAINTS:
            if c not in self.constraints[name] or self.constraints[name][c] == "" or self.constraints[name][c] is None:
                weight += len(self.objects)
            else:
                weight += len(self.constraints[name][c])
        for c in REGION_CONSTRAINTS:
            if c not in self.constraints[name] or self.constraints[name][c] == "" or self.constraints[name][c] is None:
                weight += len(self.objects)

        weight += len(self.constraints[name]['mult_conn'])
        weight -= len(self.constraints[name]['conn_excl'])

        weight += len(self.constraints[name][DISTANCE_CONSTRAINTS[0]]) * len(DISTANCE_CONSTRAINTS)

        weight -= sum(self.constraints[name]['dim_xyz']) - 4
        weight = int(round(remap(weight, 1,1000, 1, 20*len(self.objects) )))
        self.auto_weights[name] = weight
        return weight

    def get_region_weight(self, position, element):
        if "regprob" not in self.active_constraints: return -1
        if 'regprob_weight' not in self.constraints[element]: return -1
        for r in range(len(self.constraints[element]['regprob_weight'])):
            if self.grid.is_inside_region(position, self.grid.fix_position(self.constraints[element]['regprob_min'][r]), self.grid.fix_position(self.constraints[element]['regprob_max'][r])): return self.constraints[element]['regprob_weight'][r]
        return -1

    def get_weighted_options(self, position, elements):
        options = []
        active_probability = "probability" in self.active_constraints
        for name in elements:
            weight = self.get_auto_weight(name)
            region_weight = self.get_region_weight(position, name)
            if region_weight != -1: weight = region_weight
            if self.constraints[name].get('weight',-1) > -1 or weight > 0:
                weight += self.constraints[name].get('weight',1) if active_probability else 1
                options.extend([name,]*weight)
            else:
                options.extend(elements)
        return options

    def get_region_probability(self, position, element):
        if "regprop" not in self.active_constraints: return -1
        if 'regprob_probability' not in self.constraints[element]: return -1
        for r in range(len(self.constraints[element]['regprob_probability'])):
            if self.grid.is_inside_region(position, self.grid.fix_position(self.constraints[element]['regprob_min'][r]), self.grid.fix_position(self.constraints[element]['regprob_max'][r])): return self.constraints[element]['regprob_probability'][r]
        return -1

    def apply_probability_constraints(self, position, elements):
        options= []
        rand = random.random()
        random.shuffle(elements)
        for name in elements:
            p = self.constraints[name]['probability'] if "probability" in self.active_constraints else 1
            rp = self.get_region_probability(position, name)
            if rp != -1: p = rp
            if p is not None and p < 1:
                if rand < p:
                    options = [name]
                    break
            else:
                options.append(name)
        return self.get_weighted_options(position, options)

    @staticmethod
    def mirror_and_rotate_3d(coords, shape, mirror_axes=(False, False, False), rotate_axis=None, n_rotations=1):
        p = Vector(coords)
        center = Vector([(s-1)/2 for s in shape])
        generated_points = set()
    
        flip_options = [[False, True] if mirror_axes[i] else [False] for i in range(3)]
        mirrored_points = []
    
        for flip_x, flip_y, flip_z in product(*flip_options):
            q = p.copy()
            if flip_x: q.x = 2 * center.x - q.x
            if flip_y: q.y = 2 * center.y - q.y
            if flip_z: q.z = 2 * center.z - q.z
            mirrored_points.append(q)
    
        if rotate_axis is not None:
            rot_axis = Vector(rotate_axis).normalized()
        else:
            rot_axis = None
    
        for mp in mirrored_points:
            if rot_axis is None or n_rotations <= 1:
                # No rotation, just use the mirrored point
                qi = tuple(int(round(v)) for v in mp)
                if all(0 <= qi[i] < shape[i] for i in range(3)): generated_points.add(qi)
            else:
                for i in range(n_rotations):
                    theta = (2 * np.pi / n_rotations) * i
                    rot_matrix = Matrix.Rotation(theta, 4, rot_axis)
                    q_rot = rot_matrix @ (mp - center) + center
                    qi = tuple(int(round(v)) for v in q_rot)
                    if all(0 <= qi[j] < shape[j] for j in range(3)):
                        generated_points.add(qi)
    
        return generated_points

    def get_mirror_partner_and_flipping(self, element, location, point):
        x, y, z = location
        nx, ny, nz = point
        mp = element
        flipping = (1,1,1)
        if nx == x and ny == y and nz == z: return mp, flipping
        if nx != x and ny == y and nz == z:
            if self.constraints[element]["sym_mirror_axes_x"] is not None: mp = self.constraints[element]["sym_mirror_axes_x"].name
            if self.constraints[element]["sym_mirror_flip_x"]: flipping = (-1, 1, 1)
        elif nx == x and ny != y and nz == z:
            if self.constraints[element]["sym_mirror_axes_y"] is not None: mp = self.constraints[element]["sym_mirror_axes_y"].name
            if self.constraints[element]["sym_mirror_flip_y"]: flipping = (1, -1, 1)
        elif nx == x and ny == y and nz != z:
            if self.constraints[element]["sym_mirror_axes_z"] is not None: mp = self.constraints[element]["sym_mirror_axes_z"].name
            if self.constraints[element]["sym_mirror_flip_z"]: flipping = (1, 1, -1)
        elif nx != x and ny != y and nz == z:
            if self.constraints[element]["sym_mirror_axes_xy"] is not None: mp = self.constraints[element]["sym_mirror_axes_xy"].name
            if self.constraints[element]["sym_mirror_flip_xy"]: flipping = (-1, -1, 1)
        elif nx != x and ny == y and nz != z:
            if self.constraints[element]["sym_mirror_axes_xz"] is not None: mp = self.constraints[element]["sym_mirror_axes_xz"].name
            if self.constraints[element]["sym_mirror_flip_xz"]: flipping = (-1, 1, -1)
        elif nx == x and ny != y and nz != z:
            if self.constraints[element]["sym_mirror_axes_yz"] is not None: mp = self.constraints[element]["sym_mirror_axes_yz"].name
            if self.constraints[element]["sym_mirror_flip_yz"]: flipping = (1, -1, -1)
        elif nx != x and ny != y and nz != z:
            if self.constraints[element]["sym_mirror_axes_xyz"] is not None: mp = self.constraints[element]["sym_mirror_axes_xyz"].name
            if self.constraints[element]["sym_mirror_flip_xyz"]: flipping = (-1, -1, -1)
        return mp, flipping
    def apply_symmetry_constraints(self, cell):
        """Apply symmetry to collapsed cells"""
        collapsed = []
        if "symmetry" not in self.active_constraints: return collapsed
        x, y, z = cell
        if len(self.grid.grid[x,y,z])==0: return collapsed

        mirror_axes = self.constraints[self.grid.grid[x,y,z][0]]["sym_mirror_axes"]
        rotate_n = self.constraints[self.grid.grid[x,y,z][0]]["sym_rotate_n"]
        rotate_axis = self.constraints[self.grid.grid[x, y, z][0]]["sym_rotate_axis"] if rotate_n and rotate_n > 0 else None

        if mirror_axes or rotate_axis:
            points = self.mirror_and_rotate_3d(cell, self.grid.grid_size, mirror_axes, rotate_axis, rotate_n)
            for point in points:
                nx, ny, nz = point
                if x==nx and y==ny and z==nz: continue
                mp, flipping = self.get_mirror_partner_and_flipping(self.grid.grid[x,y,z][0], cell, point)
                self.grid.grid[nx, ny, nz] = [ mp ]
                if not self.grid.collapsed[nx,ny,nz]: collapsed.append(self.grid.mark_collapsed(nx,ny,nz))
                self.sympartner[nx, ny, nz] = [[x,y,z]]
                self.symflip[nx, ny, nz] = flipping
        self.sympartner[x,y,z] = collapsed
        return collapsed

    def _check_dimensions(self, cell, dimensions, flipping):
        if "dimensions" not in self.active_constraints: return True
        if sum(dimensions) == 3: return True
        x, y, z = cell
        for nx in range(dimensions[0]):
            for ny in range(dimensions[1]):
                for nz in range(dimensions[2]):
                    gx, gy, gz = x + nx * flipping[0], y + ny * flipping[1], z + nz * flipping[2]
                    if not self.grid.within_boundaries(gx, gy, gz) or self.grid.collapsed[gx, gy, gz]: return False
        return True

    def check_space(self, cell):
        x, y, z = cell
        options = []
        for element in self.grid.grid[x, y, z]:
            if self._check_dimensions(cell, self.constraints[element]["dim_xyz"], (1,1,1) if not self.symflip[x,y,z] else self.symflip[x,y,z]): options.append(element)
        return options

    def check_empty_neighbors(self, cell, options):
        if "empty" not in self.active_constraints: return options
        x, y, z = cell
        new_options = []
        for option in options:
            check_directions = True
            for direction in self.constraints[option]["empty_neighbor"]:
                if direction not in DIRECTIONS or direction.startswith("ANY"): continue
                d = DIRECTIONS[direction]
                nx, ny, nz = x+d[0], y+d[1], z+d[2]
                if not self.grid.within_boundaries(nx, ny, nz): continue
                if len(self.grid.grid[nx, ny, nz]) == 0:
                    check_directions = False
                    break
            if not check_directions: continue
            for direction in self.constraints[option]["empty_any_neighbor"]:
                if direction not in DIRECTIONS: continue
                if self.grid.count_empty_cells_in_direction(x, y, z, DIRECTIONS[direction]) > 0:
                    check_directions = False
                    break
            if check_directions: new_options.append(option)
        return new_options

    def apply_dimensions_constraints(self, cell):
        collapsed = []
        if "dimensions" not in self.active_constraints: return collapsed
        x, y, z = cell
        if not self.grid.within_boundaries(x,y,z): return collapsed
        if len(self.grid.grid[x,y,z]) == 0: return collapsed
        obj_name = self.grid.grid[x,y,z][0]
        if sum(self.constraints[obj_name]["dim_xyz"]) == 3: return collapsed
        d = self.constraints[obj_name]["dim_xyz"]
        coll = []
        fac = (1,1,1) if self.symflip[x,y,z] is None else self.symflip[x,y,z]
        for nx in range(d[0]):
            for ny in range(d[1]):
                for nz in range(d[2]):
                    gx,gy,gz = x+nx*fac[0],y+ny*fac[1],z+nz*fac[2]
                    if not self.grid.within_boundaries(gx,gy,gz) or (((nx!=0)or(ny!=0)or(nz!=0)) and self.grid.collapsed[gx,gy,gz]): continue
                    coll.append([gx,gy,gz])
        if len(coll) == np.prod(d):
            for c in coll:
                self.grid.grid[c[0], c[1], c[2]] = self.grid.grid[x, y, z]
                if not self.grid.collapsed[c[0],c[1],c[2]]: collapsed.append(self.grid.mark_collapsed(c[0], c[1], c[2]))
        else:
            self.grid.grid[x, y, z] = []
            print(f"Ooops, cell {x},{y},{z} did not collapse as expected. {obj_name} does not fit.")
        return collapsed

    def apply_transformation_constraints(self, cell, obj_name, target_obj):
        def _get_mapped_random_values(vmin, vmax, steps):
            if steps < 0 and vmin > vmax:
                steps =- steps
                sw = vmax
                vmax = vmin 
                vmin = sw
            if steps > 0 and vmax-vmin >= 0:
                v = []
                j = vmin
                while j<=vmax:
                    v.append(j)
                    j += steps
                if j-steps < vmax: v.append(vmax)
                return v[random.randrange(0,len(v))]
            else:
                return vmin + (vmax - vmin) * random.random()
        x,y,z = cell
        if obj_name not in self.constraints: return
        constraints = self.constraints[obj_name]

        if "symmetry" in self.active_constraints:
            if self.symtransform[x, y, z] is not None:
                mat = self.symtransform[x, y, z]
                tmat, smat, rmat, fmat = mat[:3], mat[3:6], mat[6:9], mat[9:]
                if self.symflip[x, y, z] is not None:
                    smat = [ a*b for a,b in zip(smat, self.symflip[x, y, z]) ]
                    if constraints['sym_mirror_flip_transl']: tmat = [ a*b for a,b in zip(tmat, self.symflip[x, y, z]) ]
                for i in range(3):
                    target_obj.location[i] += tmat[i]
                target_obj.scale.x, target_obj.scale.y, target_obj.scale.z = smat
                axis = ['X','Y','Z']
                for i in range(len(axis)):
                    if rmat[i] != 0: target_obj.rotation_euler.rotate_axis(axis[i], rmat[i])

                target_obj.scale.x *= fmat[0]
                target_obj.scale.y *= fmat[1]
                target_obj.scale.z *= fmat[2]
                return

        symtransmat = [0.0, 0.0, 0.0 , 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1, 1, 1] # transformations, scale, rotation, flipping
        noisefactor = 1 if constraints["noise_transf_function"] == 0 else get_better_noise(self.apply_noise_randomize_position_constraint(obj_name, cell), constraints, 'noise_transf')
        if "transformations" in self.active_constraints:
            if constraints["translation_min"] is not None or constraints["translation_max"] is not None or constraints["translation_steps"] is not None:
                tmin = constraints.get("translation_min",PROP_DEFAULTS["translation_min"])
                tmax = constraints.get("translation_max",PROP_DEFAULTS["translation_max"])
                ts = constraints.get("translation_steps",PROP_DEFAULTS["translation_steps"])
                loc = target_obj.location
                newloc = [0.0, 0.0, 0.0]
                for i in range(3):
                    newloc[i] = _get_mapped_random_values(tmin[i], tmax[i], ts[i])
                    if tmin[i]!=tmax[i] and noisefactor!=1: newloc[i] = remap(noisefactor, -1, 1, tmin[i], tmax[i])
                    loc[i] += newloc[i] if self.symflip[x, y, z] is None or not constraints['sym_mirror_flip_transl'] else newloc[i] * self.symflip[x, y, z][i]
                target_obj.location = loc
                symtransmat[0:3] = newloc

            if constraints["scale_type"] is not None and constraints["scale_type"] > 0:
                sm = [0.0, 0.0, 0.0]
                if constraints["scale_type"] == 1 and constraints["scale_uni"] is not None:
                    if noisefactor == 1:
                        s = _get_mapped_random_values(constraints["scale_uni"][0], constraints["scale_uni"][1], constraints["scale_uni"][2])
                    else:
                        s = remap(noisefactor, -1, 1, constraints["scale_uni"][0], constraints["scale_uni"][1])
                    sm = [s,s,s]
                if constraints["scale_type"] == 2 and constraints["scale_min"] is not None and constraints["scale_max"] is not None and constraints["scale_steps"] is not None:
                    smin = constraints["scale_min"]
                    smax = constraints["scale_max"]
                    ss = constraints["scale_steps"]
                    sm = [_get_mapped_random_values(smin[0], smax[0], ss[0]), _get_mapped_random_values(smin[1], smax[1], ss[1]), _get_mapped_random_values(smin[2], smax[2], ss[2])]
                    if noisefactor !=1:
                        if smin[0] != smax[0]: sm[0] = remap(noisefactor, -1, 1, smin[0], smax[0])
                        if smin[1] != smax[1]: sm[1] = remap(noisefactor, -1, 1, smin[1], smax[1])
                        if smin[2] != smax[2]: sm[2] = remap(noisefactor, -1, 1, smin[2], smax[2])
                target_obj.scale.x = sm[0]
                target_obj.scale.y = sm[1]
                target_obj.scale.z = sm[2]
                symtransmat[3:6] = sm

            if constraints["rotation_min"] is not None or constraints["rotation_max"] is not None or constraints["rotation_steps"] is not None:
                rmin = constraints.get("rotation_min",PROP_DEFAULTS["rotation_min"])
                rmax = constraints.get("rotation_max",PROP_DEFAULTS["rotation_max"])
                rs = constraints.get("rotation_steps",PROP_DEFAULTS["rotation_steps"])
                axis=['X','Y','Z']
                rotmat = [0.0, 0.0, 0.0]
                for i in range(3):
                    if noisefactor == 1:
                        a = _get_mapped_random_values(rmin[i], rmax[i], rs[i])
                    else:
                        a = remap(noisefactor, -1, 1, rmin[i], rmax[i])
                    rotmat[i] = a
                    if a!=0: target_obj.rotation_euler.rotate_axis(axis[i], a)
                symtransmat[6:9] = rotmat

            if constraints["flipping"] is not None and sum(constraints["flipping"]) > 0:
                rv = np.random.rand(3)
                fv = [1, 1, 1]
                pv = constraints["flipping"]
                for i in range(3):
                    if (1 - pv[i]) < rv[i]: fv[i] = -1
                target_obj.scale.x *= fv[0]
                target_obj.scale.y *= fv[1]
                target_obj.scale.z *= fv[2]
                symtransmat[9:12] = fv

        if "symmetry" in self.active_constraints:
            if self.symflip[x, y, z] is not None:
                target_obj.scale.x *= self.symflip[x, y, z][0]
                target_obj.scale.y *= self.symflip[x, y, z][1]
                target_obj.scale.z *= self.symflip[x, y, z][2]

            # transfer transformations to symmetry partners:
            if self.constraints[obj_name]['sym_mirror_trans'] and self.sympartner[x, y, z] is not None:
                for p in self.sympartner[x, y, z]: self.symtransform[p[0], p[1], p[2]] = symtransmat

    def propagate_frequency_constraints(self, cell):
        if "frequency" not in self.active_constraints and "objfreq" not in self.active_constraints: return
        x, y, z = cell
        if len(self.grid.grid[x,y,z])==0: return []
        current_obj = self.grid.grid[x,y,z][0]
        dimensions = self.constraints[current_obj]["dim_xyz"]
        dim_fac = np.prod(dimensions)
        nf = {"face": FACE_DIRECTIONS, "corner": CORNER_DIRECTIONS, "edge": EDGE_DIRECTIONS,
              "neighbor": {**FACE_DIRECTIONS, **CORNER_DIRECTIONS, **EDGE_DIRECTIONS}}
        axis = {0: [1, 0, 0], 1: [0, 1, 0], 2: [0, 0, 1]}

        if "frequency" in self.active_constraints:
            # grid frequency
            if self.constraints[current_obj]["freq_grid"] > -1:
                count = self.grid.count_obj(current_obj) / dim_fac
                if count >= self.constraints[current_obj]["freq_grid"]: self.grid.remove_obj(current_obj)

            if self.constraints[current_obj]["freq_grid_pct"] > -1:
                count = self.grid.count_obj(current_obj) / dim_fac
                max_count = self.constraints[current_obj]["freq_grid_pct"]/100 * np.prod(self.grid.grid_size)
                if count >= max_count: self.grid.remove_obj(current_obj)

            for k, direction in nf.items():
                p = f"freq_neighbor_{k}" if k != "neighbor" else "freq_neighbor"
                # neighbor frequency
                if self.constraints[current_obj][p] is not None and self.constraints[current_obj][p]>-1:
                    if self.grid.count_neighbors(x, y, z, current_obj, direction) > self.constraints[current_obj][p]:
                        self.grid.remove_neighbors(x, y, z, current_obj, direction)
                # any neighbor frequency
                p = f"freq_any_neighbor_{k}" if k != "neighbor" else "freq_any_neighbor"
                if self.constraints[current_obj][p] is not None and self.constraints[current_obj][p] > -1:
                    diff = self.constraints[current_obj][p] - self.grid.count_neighbors(x, y, z, None, direction)
                    if diff < 0: self.grid.remove_max_neighbors(x, y, z, abs(diff), direction)
            # axes
            for p, obj in {"freq_axes" : current_obj, "freq_any_axes" : None}.items():
                if self.constraints[current_obj][p] is None: continue
                max_count = self.constraints[current_obj][p]
                for i in range(3):
                    if max_count[i] < 0: continue
                    diff = max_count[i] - self.grid.count_axis_neighbors(x, y, z, obj, axis[i])[i]
                    if diff < 0: self.grid.remove_max_axis_neighbors(x, y, z, abs(diff), axis[i], obj)
            # direction
            for p, obj in {"freq_direction" : current_obj, "freq_any_direction" : None}.items():
                if self.constraints[current_obj][f"{p}_freq"] == -1: continue
                dirs = get_directions_by_name(DIRECTIONS_KEYS[self.constraints[current_obj][p]])
                freq = self.grid.count_all_neighbors(x, y, z, obj, dirs)
                diff = self.constraints[current_obj][f"{p}_freq"] - freq
                if diff < 0: self.grid.remove_max_all_neighbors(x, y, z, abs(diff), dirs, obj)
        # object frequency
        if "objfreq" in self.active_constraints:
            for i in range(len(self.constraints[current_obj]['objfreq_obj'])):
                neighbor = self.constraints[current_obj]['objfreq_obj'][i].name if self.constraints[current_obj]['objfreq_obj'][i] is not None and isinstance(self.constraints[current_obj]['objfreq_obj'][i], bpy.types.Object) else None
                for k, direction in nf.items():
                    p = f"objfreq_{k}"
                    if i < len(self.constraints[current_obj][p]) and self.constraints[current_obj][p][i] > -1:
                        diff = self.constraints[current_obj][p][i] - self.grid.count_neighbors(x, y, z, neighbor, direction)
                        if diff < 0: self.grid.remove_max_neighbors(x, y, z, abs(diff), direction, neighbor)
                if i < len(self.constraints[current_obj]["objfreq_axes"]):
                    max_count = self.constraints[current_obj]["objfreq_axes"][i]
                    for v in range(3):
                        if max_count[v] < 0 : continue
                        diff = max_count[v] - self.grid.count_axis_neighbors(x, y, z, neighbor, axis[v])[v]
                        if diff < 0 : self.grid.remove_max_axis_neighbors(x, y, z, abs(diff), axis[v], neighbor)
                if i < len(self.constraints[current_obj]["objfreq_direction_freq"]) and self.constraints[current_obj]["objfreq_direction_freq"][i] > -1:
                    direction = self.constraints[current_obj]["objfreq_direction"][i]
                    dirs = get_directions_by_name(DIRECTIONS_KEYS[direction])
                    freq = self.grid.count_all_neighbors(x, y, z, neighbor, dirs)
                    diff = self.constraints[current_obj]["objfreq_direction_freq"][i] - freq
                    if diff < 0: self.grid.remove_max_all_neighbors(x, y, z, abs(diff), dirs, neighbor)

    def propagate_region_frequency_constraints(self, cell):
        if "regfreq" not in self.active_constraints: return
        x, y, z = cell
        if len(self.grid.grid[x,y,z])==0: return
        obj_name = self.grid.grid[x,y,z][0]

        for i in range(len(self.constraints[obj_name]["regfreq_freq"])):
            rmin = self.grid.fix_position(self.constraints[obj_name]["regfreq_min"][i])
            rmax = self.grid.fix_position(self.constraints[obj_name]["regfreq_max"][i])
            freq = self.constraints[obj_name]["regfreq_freq"][i]
            freqpct = self.constraints[obj_name]["regfreq_freq_pct"][i] if "regfreq_freq_pct" in self.constraints[obj_name] and i < len(self.constraints[obj_name]["regfreq_freq_pct"]) else -1
            if freq > 0 and self.grid.is_inside_region(cell, rmin, rmax):
                self.grid.remove_max_region_neighbors(x,y,z,freq,rmin,rmax)
            if freqpct > 0 and self.grid.is_inside_region(cell, rmin, rmax):
                maxfreq = int(freqpct / 100 * abs(rmax[0] - rmin[0] + 1) * abs(rmax[1] - rmin[1] + 1) * abs(rmax[2] - rmin[2] + 1))
                self.grid.remove_max_region_neighbors(x,y,z,maxfreq,rmin,rmax)

    def propagate_distance_from_object_constraints(self, cell):
        if "distance" not in self.active_constraints: return
        mgx, mgy, mgz = self.grid.grid_size[0] - 1, self.grid.grid_size[1] - 1, self.grid.grid_size[2] - 1
        x, y, z = cell
        if len(self.grid.grid[x, y, z]) == 0: return
        obj_name = self.grid.grid[x, y, z][0]
        dimensions = self.constraints[obj_name]["dim_xyz"]
        constraints = self.constraints[obj_name]
        for i, distance in enumerate(constraints["distance"]):
            df = constraints["distance_from"][i]
            if df not in [0, 2]: return
            if df == 0 and constraints["distance_object"][i] is None: return
            if df == 2 and constraints["distance_subcollection"][i] is None: return
            minx, miny, minz = min(mgx, max(0, x - distance[0])), min(mgy, max(0, y - distance[1])), min(mgz, max(0, z - distance[2]))
            maxx, maxy, maxz = (max(0, min(mgx, x + distance[0] + dimensions[0] - 1 )), max(0, min(mgy, y + distance[1] + dimensions[1] - 1)),
                                max(0, min(mgz, z + distance[2] + dimensions[2] - 1 )))
            fon = constraints["distance_object"][i].name if df == 0 else constraints["distance_subcollection"][i].name

            if constraints["distance_type"][i] == 1:
                self.grid.remove_obj_outside_region(fon, (minx, miny, minz), (maxx, maxy, maxz))
            elif constraints["distance_type"][i] == 2:
                minx, miny, minz = min(mgx, max(0, x - distance[0] + 1)), min(mgy, max(0, y - distance[1] + 1)), min(mgz, max(0, z - distance[2] + 1))
                maxx, maxy, maxz = (max(0, min(mgx, x + distance[0] + dimensions[0] - 2)), max(0, min(mgy, y + distance[1] + dimensions[1] - 2)),
                                    max(0, min(mgz, z + distance[2] + dimensions[2] - 2)))
                self.grid.remove_obj_in_region(fon, (minx, miny, minz), (maxx, maxy, maxz), cell)
            else:
                self.grid.remove_obj_in_region(fon, (minx, miny, minz), (maxx, maxy, maxz), cell)

    def set_cache_geometry_compare(self, current_obj, obj, direction, result):
        if not direction in self.cache_geometry_compare[current_obj]:
            self.cache_geometry_compare[current_obj][direction] = { obj : result }
        else:
            self.cache_geometry_compare[current_obj][direction][obj] = result
        if not OPPOSITE_DIRECTIONS[direction] in self.cache_geometry_compare[obj]:
            self.cache_geometry_compare[obj][OPPOSITE_DIRECTIONS[direction]] = { current_obj : result }
        else:
            self.cache_geometry_compare[obj][OPPOSITE_DIRECTIONS[direction]][current_obj] = result
        return result

    def exists_cache_geometry_compare(self, current_obj, obj, direction):
        if direction in self.cache_geometry_compare[current_obj] and obj in self.cache_geometry_compare[current_obj][direction]:
            return True
        if OPPOSITE_DIRECTIONS[direction] in self.cache_geometry_compare[obj] and current_obj in self.cache_geometry_compare[obj][OPPOSITE_DIRECTIONS[direction]]:
            return True
        return False

    def get_cache_geometry_compare(self, current_obj, obj, direction):
        if direction in self.cache_geometry_compare[current_obj] and obj in self.cache_geometry_compare[current_obj][direction]:
            return self.cache_geometry_compare[current_obj][direction][obj]
        if OPPOSITE_DIRECTIONS[direction] in self.cache_geometry_compare[obj] and current_obj in self.cache_geometry_compare[obj][OPPOSITE_DIRECTIONS[direction]]:
            return self.cache_geometry_compare[obj][OPPOSITE_DIRECTIONS[direction]][current_obj]
        return True

    def compare_geometry(self, current_obj, obj, direction):
        if current_obj not in self.collection.objects or obj not in self.collection.objects: return True
        if self.exists_cache_geometry_compare(current_obj, obj, direction): return self.get_cache_geometry_compare(current_obj, obj, direction)
        if self.collection.objects[current_obj].type != 'MESH' or self.collection.objects[obj].type != 'MESH':
            return self.set_cache_geometry_compare(current_obj, obj, direction, True)

        result = True
        if self.constraints[current_obj]["geo_match_edges"]:
            cmpresult = compare_edges(self.collection.objects[current_obj], direction, self.collection.objects[obj],
                                      OPPOSITE_DIRECTIONS[direction],
                                      self.constraints[current_obj]["geo_tolerance"], self.constraints[current_obj]["geo_threshold"], self.spacing)
            result = result and cmpresult["obj_a_edges_count"] == cmpresult["obj_b_edges_count"] and cmpresult["matching_edges_count"] == cmpresult["obj_a_edges_count"]
        if self.constraints[current_obj]["geo_match_faces"]:
            cmpresult = compare_faces(self.collection.objects[current_obj], direction, self.collection.objects[obj],
                                      OPPOSITE_DIRECTIONS[direction],
                                      self.constraints[current_obj]["geo_tolerance"], self.constraints[current_obj]["geo_threshold"], self.spacing)

            result = result and cmpresult["obj_a_faces_count"] == cmpresult["obj_b_faces_count"] and cmpresult["matching_faces_count"] == cmpresult["obj_a_faces_count"]

        self.set_cache_geometry_compare(current_obj, obj, direction, result)
        return result

    def get_random_object_from_collection(self, pos, collection):
        x, y, z = pos
        if self.sympartner[x, y, z] is not None:
            if self.sympartner_obj[x, y, z] is None:
                ol = [o for o in collection.objects if not o.name.startswith(get_default_empty_name())]
                self.sympartner_obj[x, y, z] = random.choice(ol) if len(ol)>0 else []
                for p in self.sympartner[x, y, z]:
                    self.sympartner_obj[p[0],p[1],p[2]] = self.sympartner_obj[x, y, z]
            return self.sympartner_obj[x, y, z]
        return random.choice([o for o in collection.objects if not o.name.startswith(get_default_empty_name())])

    def apply_fixed_position_constraints(self, obj):
        collapsed = []
        if "fixed_position" not in self.active_constraints: return collapsed
        for idx,p in enumerate(self.constraints[obj.name]["fixed_position_xyz"]):
            if self.constraints[obj.name]["fixed_position_type"][idx] == 0:
                fp = self.grid.fix_position(p)
            else:
                mx, my, mz = self.grid.grid_size[0]-1, self.grid.grid_size[1]-1, self.grid.grid_size[2]-1
                xpct, ypct, zpct = self.constraints[obj.name]["fixed_position_pct"][idx]
                fp = self.grid.fix_position((int(mx*xpct/100), int(my*ypct/100), int(mz*zpct/100)))
            self.grid.grid[fp[0], fp[1], fp[2]] = [ obj.name ]
            collapsed.append(self.grid.mark_collapsed(fp[0], fp[1], fp[2]))
        return collapsed

    def apply_distance_from_position_constraints(self, obj):
        collapsed = []
        if "distance" not in self.active_constraints: return collapsed
        for i, distance in enumerate(self.constraints[obj.name]["distance"]):
            if self.constraints[obj.name]["distance_from"][i] == 1:
                gs = self.grid.grid_size
                mgx, mgy, mgz = gs[0] - 1, gs[1] - 1, gs[2] - 1
                if self.constraints[obj.name]["distance_position_type"][i] == 0:
                    position = self.grid.fix_position(self.constraints[obj.name]["distance_position"][i])
                else:
                    xpct, ypct, zpct = self.constraints[obj.name]["distance_position_pct"][i]
                    position = self.grid.fix_position((int(xpct*mgx/100),int(ypct*mgy/100),int(zpct*mgz/100)))
                minx, miny, minz = min(mgx, max(0, position[0] - distance[0])), min(mgy, max(0, position[1] - distance[1])), min(mgz, max(0, position[2] - distance[2]))
                maxx, maxy, maxz = max(0, min(mgx, position[0] + distance[0])), max(0, min(mgy, position[1] + distance[1])), max(0, min(mgz, position[2] + distance[2]))
                if self.constraints[obj.name]["distance_type"][i] == 0:
                    self.grid.remove_obj_in_region(obj.name, (minx, miny, minz), (maxx, maxy, maxz))
                elif self.constraints[obj.name]["distance_type"][i] == 1:
                    self.grid.remove_obj_outside_region(obj.name, (minx, miny, minz), (maxx, maxy, maxz))
                else:
                    self.grid.remove_obj_outside_region(obj.name, (minx, miny, minz), (maxx, maxy, maxz))
                    minx, miny ,minz = min(mgx, max(0, position[0] - distance[0] + 1)), min(mgy, max(0, position[1] - distance[1] + 1)), min(mgz, max(0, position[2] - distance[2] + 1))
                    maxx, maxy, maxz = max(0, min(mgx, position[0] + distance[0] - 1)), max(0, min(mgy, position[1] + distance[1] - 1)), max(0, min(mgz, position[2] + distance[2] - 1))
                    self.grid.remove_obj_in_region(obj.name, (minx, miny, minz), (maxx, maxy, maxz))

        return collapsed

    def apply_dimensions_draw_constraints(self, position, spacing, obj_name, new_obj):
        if "dimensions" not in self.active_constraints: return
        x, y, z = position
        if sum(self.constraints[obj_name]["dim_xyz"])==3: return
        d = self.constraints[obj_name]["dim_xyz"]
        # align element:
        loc = new_obj.location
        fac = (1, 1, 1) if self.symflip[x, y, z] is None else self.symflip[x, y, z]
        new_obj.location = ( loc[0] + (d[0]-1)/2 * spacing[0] * fac[0], loc[1] + (d[1]-1)/2 * spacing[1] * fac[1], loc[2] + (d[2]-1)/2 * spacing[2] * fac[2] )

        # prevent drawing:
        for nx in range(d[0]):
            for ny in range(d[1]):
                for nz in range(d[2]):
                    if self.grid.within_boundaries(x+nx*fac[0], y+ny*fac[1], z+nz*fac[2]): self.grid.grid[x+nx*fac[0], y+ny*fac[1], z+nz*fac[2]] = []

    def apply_draw_constraints(self, position, spacing, obj_name, target_obj):
        self.apply_transformation_constraints(position, obj_name, target_obj)
        self.apply_dimensions_draw_constraints(position, spacing, obj_name, target_obj)

    def check_connector_exclusion_constraints(self, current_obj, obj, direction, prop_name, opp_prop_name):
        if "connector_exclusion" not in self.active_constraints: return True
        if self.constraints[obj][opp_prop_name] in self.constraints[current_obj]["conn_excl"][direction] \
              or self.constraints[current_obj][prop_name] in self.constraints[obj]["conn_excl"][OPPOSITE_DIRECTIONS[direction]]: return False
        if set(self.constraints[obj]['mult_conn'][OPPOSITE_DIRECTIONS[direction]]) & set(self.constraints[current_obj]['conn_excl'][direction]): return False
        if set(self.constraints[current_obj]['mult_conn'][direction]) & set(self.constraints[obj]['conn_excl'][OPPOSITE_DIRECTIONS[direction]]): return False
        return True

    def check_multiple_connector_constraints(self, current_obj, obj, direction, prop_name, opp_prop_name):
        if "connector" not in self.active_constraints and "multiple_connector" not in self.active_constraints: return True
        if self.constraints[current_obj][prop_name] == "" and len(self.constraints[current_obj]['mult_conn'][direction]) == 0: return True
        multiple_connector = "multiple_connector" in self.active_constraints
        if multiple_connector:
            if self.constraints[obj][opp_prop_name] == "" and len(self.constraints[obj]['mult_conn'][OPPOSITE_DIRECTIONS[direction]]) == 0: return True
        if self.constraints[current_obj][prop_name] != "":
            if "connector" in self.active_constraints:
                if self.constraints[current_obj][prop_name] == self.constraints[obj][opp_prop_name]: return True

            if multiple_connector:
                if self.constraints[obj][opp_prop_name] != "":
                    if self.constraints[obj][opp_prop_name] in self.constraints[current_obj]["mult_conn"][direction] \
                        and self.constraints[current_obj][prop_name] in self.constraints[obj]["mult_conn"][OPPOSITE_DIRECTIONS[direction]]: return True

        if multiple_connector and set(self.constraints[current_obj]['mult_conn'][direction]) & set(self.constraints[obj]['mult_conn'][OPPOSITE_DIRECTIONS[direction]]): return True
        return False
    def propagate_adjacency_constraints(self, cell):
        # propagate neighbor constraints:
        queue = deque([ cell ] )
        while queue:
            cx, cy, cz = queue.popleft()
            if len(self.grid.grid[cx, cy, cz]) > 0:
                current_obj = self.grid.grid[cx, cy, cz][0]
            else:
                continue

            for direction, (dx, dy, dz) in DIRECTIONS.items():
                nx, ny, nz = cx + dx, cy + dy, cz + dz
                if not self.grid.within_boundaries(nx, ny, nz) or self.grid.collapsed[nx, ny, nz] or direction.startswith('ANY'): continue
                neighbor_options = self.grid.grid[nx, ny, nz]

                dirlower = direction.lower()
                oppdirlower = OPPOSITE_DIRECTIONS[direction].lower()

                # Filter disallowed neighbor options
                if "neighbor" in self.active_constraints:
                    new_options = [obj
                                   for obj in neighbor_options
                                   if (self.constraints[current_obj][dirlower] is None or obj in self.constraints[current_obj][dirlower])
                                   and (self.constraints[obj][oppdirlower] is None or current_obj in self.constraints[obj][oppdirlower])
                                   ]
                    if len(new_options) == 0 and self.constraints[current_obj]['allow_neighbor_constraint_violations']:
                        new_options = [obj for obj in neighbor_options if self.constraints[obj]['allow_neighbor_constraint_violations']]
                else:
                    new_options = neighbor_options
                # Filter disallowed connector options:
                prop_name = 'conn_' + dirlower
                opp_prop_name = 'conn_' + oppdirlower
                new_options = [obj for obj in new_options
                               if self.check_connector_exclusion_constraints(current_obj, obj, direction, prop_name, opp_prop_name)
                                  and self.check_multiple_connector_constraints(current_obj, obj, direction, prop_name, opp_prop_name)
                               ]

                # Filter disallowed geometry:
                if "geometry" in self.active_constraints:
                    if self.constraints[current_obj]['geo_match_edges'] or self.constraints[current_obj]['geo_match_faces']:
                        if direction in FACE_DIRECTIONS and self.constraints[current_obj][f"geo_{dirlower}"]:
                            new_options = [obj for obj in new_options if self.compare_geometry(current_obj, obj, direction)]

                if len(new_options) >= len(neighbor_options): continue
                self.grid.grid[nx, ny, nz] = new_options
                if len(new_options) == 1: queue.append((nx, ny, nz))

    def apply_post_init_constraints(self):
        collapsed = []
        for obj in self.objects:
            collapsed.extend(self.apply_fixed_position_constraints(obj))
            collapsed.extend(self.apply_distance_from_position_constraints(obj))
        return collapsed

    def collapse(self, cell):
        """Collapse a grid cell with constraints"""
        x, y, z = cell
        options = self.apply_probability_constraints(cell, self.check_empty_neighbors(cell, self.check_space(cell)))
        self.grid.grid[x, y, z] = [random.choice(options)] if len(options) > 0 else []
        return [ self.grid.mark_collapsed(x, y, z) ]

    def propagate(self, collapsed):
        """Propagate constraints"""
        queue = deque(collapsed)
        c1 = []
        c2 = []
        while queue:
            cell = queue.popleft()

            if cell not in c1: ## prevent double application
                nc = self.apply_symmetry_constraints(cell)
                c1.extend(nc)
                collapsed.extend(nc)
                queue.extend(nc)

            self.propagate_region_frequency_constraints(cell)
            self.propagate_frequency_constraints(cell)
            self.propagate_distance_from_object_constraints(cell)

            if cell not in c2:  ## prevent double application
                nc = self.apply_dimensions_constraints(cell)
                c2.extend(nc)
                collapsed.extend(nc)
                queue.extend(nc)

            self.propagate_adjacency_constraints(cell)

        return collapsed
    def propagate_post_gen_constraints(self):
        ## propagate empty neighbor constraints:
        if "empty" in self.active_constraints:
            for x in range(self.grid.grid_size[0]):
                for y in range(self.grid.grid_size[1]):
                    for z in range(self.grid.grid_size[2]):
                        self.grid.grid[x,y,z] = self.check_empty_neighbors((x,y,z), self.grid.grid[x,y,z])
    def clean(self):
        self.grid = None
        self.constraints = None
        self.objects = None
        self.auto_weights = None
        self.sympartner_obj = None
        self.sympartner = None
        self.symflip = None
        self.symtransform = None
        self.cache_geometry_compare = None
        self.collection = None
        self.spacing = None
        self.noise_pos = None
        self.active_constraints = None