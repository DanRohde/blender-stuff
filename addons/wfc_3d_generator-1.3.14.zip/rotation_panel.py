import bpy
from .helper import get_icon_name, get_selected_items, render_source_collection, get_info_icon, get_warning_icon
from .edit_panel import WFC3DULObjectFilter
class VIEW3D_UL_RotationPanelMultiSelList(bpy.types.UIList, WFC3DULObjectFilter):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        layout.row(align=True).prop(item, "selected", text=item.obj.name, icon=get_icon_name(item))

class VIEW3D_PT_RotationToolPanel(bpy.types.Panel):
    """User interface for WFC 3D Add-On"""
    bl_label = "WFC 3D Rotation Tool"
    bl_idname = "VIEW3D_PT_wfc_rotation_tool"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'WFC 3D Edit'
    bl_options = {'DEFAULT_CLOSED'}
    def draw(self, context):
        layout = self.layout
        props = context.scene.wfc_props
        render_source_collection(context, layout)

        if not props.collection_obj: return
        newrow = layout.box().row()
        nc = newrow.column().box()
        nc.operator("object.wfc_rotation_get_selected_object", icon="SELECT_SET")
        nc.prop(props, "rt_auto_active_object", icon="TRIA_RIGHT")
        nc.operator("object.wfc_update_collection_list", icon="FILE_REFRESH")
        nc = newrow.column()
        nc.template_list("VIEW3D_UL_RotationPanelMultiSelList", "", props, "rt_list", props, "rt_list_idx")
        nc.enabled = not props.rt_auto_active_object
        nc = newrow.column().box()
        nc.operator("object.wfc_rotation_select_dropdown_object", icon='RESTRICT_SELECT_OFF')
        nc.operator("object.wfc_list_select_all", icon="CHECKBOX_HLT").list_name = "rt_list"
        nc.operator("object.wfc_list_select_none", icon="CHECKBOX_DEHLT").list_name = "rt_list"
        nc.operator("object.wfc_list_invert_selection", icon="CHECKMARK", text="").list_name = "rt_list"


        nc.enabled = not props.rt_auto_active_object

        selected = get_selected_items(props.rt_list)
        if len(selected) == 0: return

        box = layout.box()
        box.row().label(text="Rotate constraints:")
        row = box.row(align=True)

        row.column(align=True)
        row.column(align=True).prop(props, "rt_neighbor")
        row.column(align=True).prop(props, "rt_connector")
        row.column(align=True).prop(props, "rt_geometry")

        row = box.row(align=True)
        row.column(align=True)
        row.column(align=True).prop(props, "rt_conn_excl")
        row.column(align=True).prop(props, "rt_mult_conn")
        row.column(align=True).prop(props, "rt_empty")
        row = box.row(align=True)
        row.column(align=True)
        row.column(align=True).prop(props, "rt_dimensions")

        if not props.rt_neighbor and not props.rt_connector and not props.rt_geometry and not props.rt_conn_excl and not props.rt_mult_conn and not props.rt_empty: return

        layout.separator()

        box = layout.box()
        row = box.row(align=True)
        row.column(align=True).label(text="Angles:")
        row.column(align=True).label(text="90°")
        row.column(align=True).label(text="180°")
        row.column(align=True).label(text="270°")
        box.row().prop(props, "rt_rotation_x")
        box.row().prop(props, "rt_rotation_y")
        box.row().prop(props, "rt_rotation_z")


        rot_enabled = sum(props.rt_rotation_x) != 0 or sum(props.rt_rotation_y) != 0 or sum(props.rt_rotation_z) != 0

        layout.separator()
        row  = layout.box().row(align=True)
        row.prop(props, "rt_offset")
        row.enabled = rot_enabled
        layout.separator()
        copies = len(selected)*(sum(props.rt_rotation_x)+sum(props.rt_rotation_y)+sum(props.rt_rotation_z))

        if copies > 0:
            layout.label(text=f"{copies} copies will be created." if copies > 1 else f"One copy will be created.", icon=get_info_icon())
        else:
            layout.label(text="Please select at least one rotation angle!", icon=get_warning_icon())
        row = layout.row(align=True)
        row.operator("object.wfc_rotation")
        row.enabled = rot_enabled



panels = [ VIEW3D_UL_RotationPanelMultiSelList, VIEW3D_PT_RotationToolPanel ]
